package project62.project62;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project62ApplicationTests {

	@Test
	void contextLoads() {
	}

}
