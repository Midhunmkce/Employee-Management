package project62.project62;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/zohoEmployee")
public class EmploymentController {
	@Autowired
	private EmploymentService eservice;
	@PostMapping("/addemployee")
	public String addemployee(@RequestBody Employment e)
	{
		eservice.addemployee(e);
		return "Employee added successfully";
		
	}
	@DeleteMapping("/deleteemployee/{id}")
	public String deleteemployee (@PathVariable long id )
	{
		eservice.deleteemployee(id);
		return "Employee deleted successfully";
		
	}
	@GetMapping("/getemployee/{id}")
	public Optional findbyid(@PathVariable long id)
	{
		return eservice.findbyid(id);
	}
	@PutMapping("/updateemployee/{id}")
	public void updateemployee(@PathVariable long id)
	{
		eservice.updateemployee(id);
	}
	  @GetMapping("/getallemployees")
	    public List<Employment> getallemployees() {
	        return eservice.getallemployees();
	    }
	

}
