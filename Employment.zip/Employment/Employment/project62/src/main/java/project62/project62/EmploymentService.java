package project62.project62;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmploymentService {
	@Autowired
	private EmploymentRepository erepository;
	
	public void addemployee (Employment e)
	{
		erepository.save(e);
	}
	public void  deleteemployee(long id)
	{
		erepository.deleteById(id);
	}
	public Optional<Employment> findbyid(long id)
	{
		return erepository.findById(id);
		
	}
	public void updateemployee(long id)
	{
		erepository.save(id);
	}
	 public List<Employment> getallemployees() {
	        return erepository.findAll(); 
	    }
	

}
