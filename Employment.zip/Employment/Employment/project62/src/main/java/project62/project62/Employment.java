package project62.project62;
import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@Entity
@Table(name="Employment_details")


public class Employment {
	@Id
	private Long emp_id;
	
	//@Column
	private String emp_name;
	private String emp_department;
	private String emp_grade;
	private Double emp_salary;
	private LocalDate emp_date_of_join;
	public Long getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(Long emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getEmp_department() {
		return emp_department;
	}
	public void setEmp_department(String emp_department) {
		this.emp_department = emp_department;
	}
	public String getEmp_grade() {
		return emp_grade;
	}
	public void setEmp_grade(String emp_grade) {
		this.emp_grade = emp_grade;
	}
	public Double getEmp_salary() {
		return emp_salary;
	}
	public void setEmp_salary(Double emp_salary) {
		this.emp_salary = emp_salary;
	}
	public LocalDate getEmp_date_of_join() {
		return emp_date_of_join;
	}
	public void setEmp_date_of_join(LocalDate emp_date_of_join) {
		this.emp_date_of_join = emp_date_of_join;
	}
	
	
	

}
